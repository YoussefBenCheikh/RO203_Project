# This file contains methods to solve an instance (heuristically or with CPLEX)
using JuMP
using CPLEX

include("generation.jl")
include("io.jl")

TOL = 0.00001

"""
Solve an instance with CPLEX
"""
function cplexSolve(grid::Array{Int,2})
    n=size(grid,1)
    # Create the model
    m = Model(CPLEX.Optimizer)
    @variable(m,x[1:n, 1:n],Bin)
    
    for c in 1:n
    	for l in 1:n
    		if c==1
    			if l==1
    				@constraint(m,(grid[c,l]+x[c,l]+x[c, l+1]+x[c+1, l]-1)^2>=1)
    				@constraint(m,(grid[c,l]+x[c,l]+x[c, l+1]+x[c+1, l]-3)^2>=1)
    				@constraint(m,(grid[c,l]+x[c,l]+x[c, l+1]+x[c+1, l]-5)^2>=1)
    			
    			elseif l==n
    				@constraint(m, (grid[c,l]+x[c,l]+x[c, l-1]+x[c+1, l]-1)^2>=1)
    				@constraint(m, (grid[c,l]+x[c,l]+x[c, l-1]+x[c+1, l]-3)^2>=1)
    				@constraint(m, (grid[c,l]+x[c,l]+x[c, l-1]+x[c+1, l]-5)^2>=1)
    			else
    				@constraint(m, (grid[c,l]+x[c,l]+x[c, l+1]+x[c, l-1]+x[c+1, l]-1)^2>=1)
    				@constraint(m, (grid[c,l]+x[c,l]+x[c, l+1]+x[c, l-1]+x[c+1, l]-3)^2>=1)
    				@constraint(m, (grid[c,l]+x[c,l]+x[c, l+1]+x[c, l-1]+x[c+1, l]-5)^2>=1)
    			end
    		
    		elseif c==n
    			if l==1
    				@constraint(m, (grid[c,l]+x[c,l]+x[c, l+1]+x[c-1, l]-1)^2>=1)
    				@constraint(m, (grid[c,l]+x[c,l]+x[c, l+1]+x[c-1, l]-3)^2>=1)
    				@constraint(m, (grid[c,l]+x[c,l]+x[c, l+1]+x[c-1, l]-5)^2>=1)
    			elseif l==n
    				@constraint(m,(grid[c,l]+x[c,l]+x[c, l-1]+x[c-1, l]-1)^2>=1)
    				@constraint(m,(grid[c,l]+x[c,l]+x[c, l-1]+x[c-1, l]-3)^2>=1)
    				@constraint(m,(grid[c,l]+x[c,l]+x[c, l-1]+x[c-1, l]-5)^2>=1)    			
    			else
    				@constraint(m,(grid[c,l]+x[c,l]+x[c, l+1]+x[c, l-1]+x[c-1, l]-1)^2>=1)
    				@constraint(m,(grid[c,l]+x[c,l]+x[c, l+1]+x[c, l-1]+x[c-1, l]-3)^2>=1)
    				@constraint(m,(grid[c,l]+x[c,l]+x[c, l+1]+x[c, l-1]+x[c-1, l]-5)^2>=1)
    			end
    		
    		else
    			if l==1
    				@constraint(m,(grid[c,l]+x[c,l]+x[c, l+1]+x[c+1, l]+x[c-1, l]-1)^2>=1)
    				@constraint(m,(grid[c,l]+x[c,l]+x[c, l+1]+x[c+1, l]+x[c-1, l]-3)^2>=1)
    				@constraint(m,(grid[c,l]+x[c,l]+x[c, l+1]+x[c+1, l]+x[c-1, l]-5)^2>=1)
    			
    			elseif l==n
    				@constraint(m,(grid[c,l]+x[c,l]+x[c, l-1]+x[c+1, l]+x[c-1, l]-1)^2>=1)
    				@constraint(m,(grid[c,l]+x[c,l]+x[c, l-1]+x[c+1, l]+x[c-1, l]-3)^2>=1)
    				@constraint(m,(grid[c,l]+x[c,l]+x[c, l-1]+x[c+1, l]+x[c-1, l]-5)^2>=1)
    			
    			else
    				@constraint(m,(grid[c,l]+x[c,l]+x[c, l+1]+x[c, l-1]+x[c+1,l]+x[c-1, l]-1)^2>=1)
    				@constraint(m,(grid[c,l]+x[c,l]+x[c, l+1]+x[c, l-1]+x[c+1,l]+x[c-1, l]-3)^2>=1)
    				@constraint(m,(grid[c,l]+x[c,l]+x[c, l+1]+x[c, l-1]+x[c+1,l]+x[c-1, l]-5)^2>=1)
    			end
 		end
    	end
    end
    
    # solve in a minimum of flips
    @objective(m, Min, sum(x[i,j] for i in 1:n for j in 1:n))
    


    # Start a chronometer
    start = time()

    # Solve the model
    optimize!(m)
    # Return:
    # 1 - true if an optimum is found
    # 2 - the solution
    # 3 - the resolution time
    return JuMP.primal_status(m) == JuMP.MathOptInterface.FEASIBLE_POINT,x, time() - start
    
end
	



"""
Heuristically solve an instance
"""
function heuristicSolve(grid::Array{Int,2})

    # TODO
   	    isOptimal = false
	    n=size(grid,1)
	    gridCopy = copy(grid)
	    Flipped = fill(0, n, n)
	    startingTime = time()
	    resolutionTime = 0
	    while sum(gridCopy[i,j] for i in 1:n for j in 1:n)!=0 && resolutionTime < 100
	    	i,j = getCellToFlip(gridCopy)	    	
	    	Flipped[i,j] = (Flipped[i,j]+1)%2
	    	gridCopy = flipGrid(gridCopy,i,j)
	    	resolutionTime = time() - startingTime
	    end
	    if sum(gridCopy[i,j] for i in 1:n for j in 1:n)==0
	    	isOptimal = true
	    end
	    return isOptimal, Flipped, resolutionTime
    
end 


function getCellToFlip(grid::Array{Int,2})
	n=size(grid,1)
	for i in 1:n
	imin = max(i-1,1)
	imax = min(i+1,n)
		for j in 1:n
			jmin = max(j-1,1)
			jmax = min(j+1,n)
			if sum(flipGrid(grid,i,j)[ii,j] for ii in imin:imax) + sum(flipGrid(grid,i,j)[i,jj] for jj in jmin:jmax) == 0
				return i,j
			end
		end
	end
	return rand(1:n),rand(1:n)
end

function flipGrid(grid::Array{Int,2}, i::Int, j::Int)
	n = size(grid,1)
	gridCopy = copy(grid)
	gridCopy[i,j] = (gridCopy[i,j]+1)%2
	if i>1
		gridCopy[i-1,j] = (gridCopy[i-1,j]+1)%2
	end
	if j>1
		gridCopy[i,j-1] = (gridCopy[i,j-1]+1)%2
	end
	if i<n
		gridCopy[i+1,j] = (gridCopy[i+1,j]+1)%2
	end
	if j<n 
		gridCopy[i,j+1] = (gridCopy[i,j+1]+1)%2
	end
	return gridCopy
end

"""
Solve all the instances contained in "../data" through CPLEX and heuristics

The results are written in "../res/cplex" and "../res/heuristic"

Remark: If an instance has previously been solved (either by cplex or the heuristic) it will not be solved again
"""
function solveDataSet()

    dataFolder = "../data/"
    resFolder = "../res/"

    # Array which contains the name of the resolution methods
    #resolutionMethod = ["cplex"]
    resolutionMethod = ["cplex", "heuristique"]

    # Array which contains the result folder of each resolution method
    resolutionFolder = resFolder .* resolutionMethod

    # Create each result folder if it does not exist
    for folder in resolutionFolder
        if !isdir(folder)
            mkdir(folder)
        end
    end
            
    global isOptimal = false
    global solveTime = -1

    # For each instance
    # (for each file in folder dataFolder which ends by ".txt")
    for file in filter(x->occursin(".txt", x), readdir(dataFolder))  
        
        println("-- Resolution of ", file)
        grid = readInputFile(dataFolder * file)

        # TODO
        #println("In file resolution.jl, in method solveDataSet(), TODO: read value returned by readInputFile()")
        
        # For each resolution method
        for methodId in 1:size(resolutionMethod, 1)
            
            outputFile = resolutionFolder[methodId] * "/" * file

            # If the instance has not already been solved by this method
            if !isfile(outputFile)
                
                fout = open(outputFile, "w")
                println(fout, "t = [")  

                resolutionTime = -1
                isOptimal = false
                
                # If the method is cplex
                if resolutionMethod[methodId] == "cplex"
                    
                    # TODO 
                    println("In file resolution.jl, in method solveDataSet(), TODO: fix cplexSolve() arguments and returned values")
                    
                    # Solve it and get the results
                    isOptimal, x, resolutionTime = cplexSolve(grid)
                    Solution = round.(Int,value.(x))
                    # If a solution is found, write it
                    if isOptimal
                        # TODO
                        #println("In file resolution.jl, in method solveDataSet(), TODO: write cplex solution in fout")
                        writedlm(fout, Solution)
                        println(fout,"")
                    end

                # If the method is one of the heuristics
                else
                    
                    

                    
                    
                    
                        # TODO 
                	 #println("In file resolution.jl, in method solveDataSet(), TODO: fix heuristicSolve() arguments and returned values")
                        
                        # Solve it and get the results
                        isOptimal, x, resolutionTime = heuristicSolve(grid)
                    	 Solution = round.(Int,value.(x))
                        # Write the solution (if any)
                        if isOptimal

                        # TODO
                        #println("In file resolution.jl, in method solveDataSet(), TODO: write the heuristic solution in fout")
                        	writedlm(fout, Solution)
                        	
                        end 
                end
		 println(fout, "]")
                println(fout, "solveTime = ", resolutionTime) 
                println(fout, "isOptimal = ", isOptimal)
                
                
                # TODO
                #println("In file resolution.jl, in method solveDataSet(), TODO: write the solution in fout") 
                close(fout)
            end


            # Display the results obtained with the method on the current instance
            #include(outputFile)
            println(resolutionMethod[methodId], " optimal: ", isOptimal)
            println(resolutionMethod[methodId], " time: " * string(round(solveTime, sigdigits=2)) * "s\n")
        end         
    end 
end
