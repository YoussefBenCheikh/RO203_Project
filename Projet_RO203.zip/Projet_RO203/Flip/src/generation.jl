# This file contains methods to generate a data set of instances for the flip game
#include("io.jl")
using DelimitedFiles

"""
Generate an n*n grid with a given density

Argument
- n: size of the grid
"""
function generateInstance(n::Int64)

    # TODO
	grid = fill(0, n, n)
	numberFlips = n^2
	for _ in 1:numberFlips
		i = rand(1:n)
		j = rand(1:n)
		grid = flipGrid(grid,i,j)
	end
	return grid
	
end

function flipGrid(grid::Array{Int,2}, i::Int, j::Int)
	n = size(grid,1)
	gridCopy = copy(grid)
	gridCopy[i,j] = (gridCopy[i,j]+1)%2
	if i>1
		gridCopy[i-1,j] = (gridCopy[i-1,j]+1)%2
	end
	if j>1
		gridCopy[i,j-1] = (gridCopy[i,j-1]+1)%2
	end
	if i<n
		gridCopy[i+1,j] = (gridCopy[i+1,j]+1)%2
	end
	if j<n 
		gridCopy[i,j+1] = (gridCopy[i,j+1]+1)%2
	end
	return gridCopy
end
 

"""
Generate all the instances

Remark: a grid is generated only if the corresponding output file does not already exist
"""
function generateDataSet()

    
# For each grid size considered
    for size in [3, 4, 5, 6, 7]
            for instance in 1:20
                fileName = "../data/instance_t" * string(size) * "_" * string(instance) * ".txt"
                if !isfile(fileName)
                    println("-- Generating file " * fileName)
                    writer = open(fileName, "w")
                    writedlm(writer, generateInstance(size))
                    close(writer)
                end 
            end
        
    end
    
end
